import { Event } from '../models/eventModel.js';
import { asyncHandler } from "../errorHander/asyncHandler.js";
import { ApiError } from "../errorHander/ApiError.js";
import { ApiResponse } from "../errorHander/ApiResponse.js";
import path from "path";
import fs from "fs"
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Controller function to store an event
export const createEvent = asyncHandler(async (req, res, next) => {
    try {
        const user = req.user
        const {
            eventName,
            category,
            location,
            fromDate,
            fromTime,
            toDate,
            toTime
        } = req.body;
        if (!eventName || !category || !location || !fromDate || !fromTime || !toDate) {
            return next(new ApiError("Volt Type andimage is required.", 400));
        }

        const image = req.file;

        const imagePath = path.join(__dirname, `../../public/assets/eventImages/${path.extname(image.originalname)}`);
        fs.renameSync(image.path, imagePath);

        const imageUrl = `/public/assets/eventImages/${user._id}${path.extname(image.originalname)}`;

        // Create a new Event instance with the provided data
        const event = new Event({
            eventManger: req.user._id,
            eventName,
            category,
            location,
            fromDate,
            fromTime,
            toDate,
            toTime,
            imageUrl: imageUrl
        });

        // Save the event to the database
        const savedEvent = await event.save();

        return res.status(200).json(
            new ApiResponse(200, savedEvent, "Event Created Successfully.")
        );
    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Internal Server Error' });
    }
});

export const deleteEvent = asyncHandler(async (req, res, next) => {
    try {
        const eventId = req.params.id;

        // Check if the event exists
        const existingEvent = await Event.findById(eventId);
        if (!existingEvent) {
            return next(new ApiError("Event not found", 404));
        }

        // Delete the event
        await Event.findByIdAndDelete(eventId);

        return res.status(200).json(
            new ApiResponse(200, {}, "Event Deleted Successfully.")
        );
    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Internal Server Error' });
    }
});

export const updateEvent = asyncHandler(async (req, res, next) => {
    try {
        const eventId = req.params.id;
        const {
            eventName,
            category,
            location,
            fromDate,
            fromTime,
            toDate,
            toTime,
            imageUrl
        } = req.body;

        // Check if the event exists
        const existingEvent = await Event.findById(eventId);
        if (!existingEvent) {
            return next(new ApiError("Event not found", 404));
        }
        // Update the event
        existingEvent.eventName = eventName;
        existingEvent.category = category;
        existingEvent.location = location;
        existingEvent.fromDate = fromDate;
        existingEvent.fromTime = fromTime;
        existingEvent.toDate = toDate;
        existingEvent.toTime = toTime;
        existingEvent.imageUrl = imageUrl;

        const updatedEvent = await existingEvent.save();

        return res.status(200).json(
            new ApiResponse(200, updatedEvent, "Event Updated Successfully.")
        );
    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Internal Server Error' });
    }
});

export const getEvent = asyncHandler(async (req, res, next) => {
    try {
        const eventId = req.params.id;; // Assuming eventId is passed as a URL parameter
        console.log(eventId)
        // Find the event by its ID
        const event = await Event.findById(eventId) // Adjust the population fields as needed

        if (!event) {
            return next(new ApiError('Event not found', 404));
        }

        return res.status(200).json(
            new ApiResponse(200, event, 'Event Details Retrieved Successfully.')
        );
    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Internal Server Error' });
    }
});


