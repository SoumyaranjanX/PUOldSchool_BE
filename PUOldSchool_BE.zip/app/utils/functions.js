const getLoggedInUserId = () => {
    return "user"
}

export {
    getLoggedInUserId
}